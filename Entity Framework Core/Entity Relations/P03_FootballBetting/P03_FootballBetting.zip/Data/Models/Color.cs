﻿using System.Collections.Generic;

namespace P03_FootballBetting.Data.Models
{
    public class Color
    {
        public Color()
        {
            this.PrimaryKitColor = new HashSet<Team>();
            this.SecondaryKitColor = new HashSet<Team>();
        }
        public int ColorId { get; set; }

        public string Name { get; set; }

        public ICollection<Team> PrimaryKitColor { get; set; }
        public ICollection<Team> SecondaryKitColor { get; set; }
    }
}
